// Gráfico de gastos/ingresos por categoría o descripción (con filtros)
let gastosChart = null;
function initGastosChart() {
    const canvas = document.getElementById('gastosPorCategoriaChart');
    if (!canvas) return;
    const tipoSel = document.getElementById('gastosTipoFilter');
    const agruparSel = document.getElementById('gastosAgruparFilter');

    function render() {
        // data-url ya trae ?year=...&month=...; añadimos los filtros
        let url = canvas.dataset.url;
        if (tipoSel) url += '&tipo=' + tipoSel.value;
        if (agruparSel) url += '&agrupar=' + agruparSel.value;
        fetch(url)
            .then(resp => resp.json())
            .then(data => {
                if (gastosChart) gastosChart.destroy();
                gastosChart = new Chart(canvas, {
                    type: 'doughnut',
                    data: {
                        labels: data.labels,
                        datasets: [{
                            data: data.data,
                            backgroundColor: [
                                '#FF6384', '#36A2EB', '#FFCE56',
                                '#4BC0C0', '#9966FF', '#FF9F40'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { position: 'top' } }
                    }
                });
            });
    }

    if (tipoSel) tipoSel.addEventListener('change', render);
    if (agruparSel) agruparSel.addEventListener('change', render);
    render();
}

// Gráfico de ingresos vs gastos
function initFlujoDineroChart() {
    const canvas = document.getElementById('flujoDeDineroChart');
    if (!canvas) return;
    const url = canvas.dataset.url;
    fetch(url)
        .then(resp => resp.json())
        .then(data => {
            new Chart(canvas, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Flujo de Dinero',
                        data: data.data,
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.6)',
                            'rgba(255, 99, 132, 0.6)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 99, 132, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: value => '$' + value.toLocaleString()
                            }
                        }
                    },
                    plugins: { legend: { display: false } }
                }
            });
        });
}

// Gráfico de evolución de inversión
function initInversionesChart() {
    const canvas = document.getElementById('investmentLineChart');
    if (!canvas) return;
    //const labels = JSON.parse(canvas.dataset.labels || '[]');
    //const data = JSON.parse(canvas.dataset.values || '[]');
    const url = canvas.dataset.url;
    fetch(url)
        .then(resp => resp.json())
        .then(data => {
            new Chart(canvas, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Capital Invertido Acumulado',
                        data: data.data,
                        fill: true,
                        borderColor: '#4F46E5',
                        backgroundColor: 'rgba(79, 70, 229, 0.1)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: value => '$' + value.toLocaleString()
                            }
                        }
                    },
                    plugins: { legend: { display: false } }
                }
            });
        });
}

function initBudgetVsActualChart() {
    console.log("initBudgetVsActualChart called");
    const canvas = document.getElementById('budgetVsActualChart');
    if (!canvas) {
        console.log("canvas budgetVsActualChart not found");
        return;
    }
    const url = canvas.dataset.url;
    if (!url) {
        console.log("no data-url on canvas");
        return;
    }
    console.log("Fetching budget data from", url);

    fetch(url)
        .then(resp => resp.json())
        .then(data => {
            console.log("Budget data received:", data);
            new Chart(canvas, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [
                        {
                            label: 'Gasto Real',
                            data: data.real,
                            backgroundColor: '#4F46E5', // Indigo-600
                            borderRadius: 4
                        },
                        {
                            label: 'Presupuesto',
                            data: data.presupuestado,
                            backgroundColor: '#C7D2FE', // Indigo-200
                            borderRadius: 4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                borderDash: [2, 4],
                                color: '#f3f4f6'
                            },
                            ticks: {
                                callback: value => '$' + value.toLocaleString()
                            }
                        },
                        x: {
                            grid: { display: false }
                        }
                    },
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        });
}

document.addEventListener('DOMContentLoaded', () => {
    initGastosChart();
    initFlujoDineroChart();
    initInversionesChart();
    initBudgetVsActualChart();
});